/*
 * Copyright (c) 1997, 2018 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 *  Author: Sekhar Vajjhala
 *
 *  $Id: USAddress.java,v 1.1 2007-12-05 00:49:37 kohsuke Exp $
 */  

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="usaddr")
public class USAddress {
    private String _name;
    private String _street;

    public String getName() {
        return _name;
    }

    public String getStreet() {
        return _street;
    }
}
